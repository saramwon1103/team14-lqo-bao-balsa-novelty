/*+ NestLoop(mi rt ci k mk n chn it an t mc cn)
 NestLoop(mi rt ci k mk n chn it an t mc)
 HashJoin(mi rt ci k mk n chn it an t)
 NestLoop(mi rt ci k mk n chn it an)
 MergeJoin(mi rt ci k mk n chn it)
 HashJoin(mi rt ci k mk n chn)
 NestLoop(rt ci k mk n chn)
 HashJoin(rt ci k mk n)
 NestLoop(ci k mk n)
 HashJoin(ci k mk)
 NestLoop(k mk)
 SeqScan(mi)
 SeqScan(rt)
 SeqScan(ci)
 IndexScan(k)
 IndexScan(mk)
 IndexScan(n)
 IndexScan(chn)
 SeqScan(it)
 IndexScan(an)
 SeqScan(t)
 IndexScan(mc)
 IndexScan(cn)
 Leading(((((((mi ((rt ((ci (k mk)) n)) chn)) it) an) t) mc) cn)) */
SELECT MIN(chn.name) AS voiced_char_name,
       MIN(n.name) AS voicing_actress_name,
       MIN(t.title) AS voiced_action_movie_jap_eng
FROM aka_name AS an,
     char_name AS chn,
     cast_info AS ci,
     company_name AS cn,
     info_type AS it,
     keyword AS k,
     movie_companies AS mc,
     movie_info AS mi,
     movie_keyword AS mk,
     name AS n,
     role_type AS rt,
     title AS t
WHERE ci.note IN ('(voice)',
                  '(voice: Japanese version)',
                  '(voice) (uncredited)',
                  '(voice: English version)')
  AND cn.country_code ='[us]'
  AND it.info = 'release dates'
  AND k.keyword IN ('hero',
                    'martial-arts',
                    'hand-to-hand-combat')
  AND mi.info IS NOT NULL
  AND (mi.info LIKE 'Japan:%201%'
       OR mi.info LIKE 'USA:%201%')
  AND n.gender ='f'
  AND n.name LIKE '%An%'
  AND rt.role ='actress'
  AND t.production_year > 2010
  AND t.id = mi.movie_id
  AND t.id = mc.movie_id
  AND t.id = ci.movie_id
  AND t.id = mk.movie_id
  AND mc.movie_id = ci.movie_id
  AND mc.movie_id = mi.movie_id
  AND mc.movie_id = mk.movie_id
  AND mi.movie_id = ci.movie_id
  AND mi.movie_id = mk.movie_id
  AND ci.movie_id = mk.movie_id
  AND cn.id = mc.company_id
  AND it.id = mi.info_type_id
  AND n.id = ci.person_id
  AND rt.id = ci.role_id
  AND n.id = an.person_id
  AND ci.person_id = an.person_id
  AND chn.id = ci.person_role_id
  AND k.id = mk.keyword_id;

