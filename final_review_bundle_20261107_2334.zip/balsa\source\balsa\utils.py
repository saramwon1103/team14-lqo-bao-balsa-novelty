# Copyright 2022 The Balsa Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import balsa


def SanitizeToText(d):
    """Sanitizes result/config dicts for W&B textual logging."""
    # For configs: flattens all so w&b can visualize nicely.
    # Don't quote all because otherwise scalars are converted to strings.
    ret, _ = balsa.hyperparams.ToFlattenedTextDict(d, quote_all=False)
    return ret
