/*+ NestLoop(t k mk mc cn)
 HashJoin(t k mk mc)
 HashJoin(t k mk)
 HashJoin(k mk)
 SeqScan(t)
 IndexScan(k)
 IndexScan(mk)
 SeqScan(mc)
 IndexScan(cn)
 Leading((((t (k mk)) mc) cn)) */
SELECT MIN(t.title) AS movie_title
FROM company_name AS cn,
     keyword AS k,
     movie_companies AS mc,
     movie_keyword AS mk,
     title AS t
WHERE cn.country_code ='[nl]'
  AND k.keyword ='character-name-in-title'
  AND cn.id = mc.company_id
  AND mc.movie_id = t.id
  AND t.id = mk.movie_id
  AND mk.keyword_id = k.id
  AND mc.movie_id = mk.movie_id;

