/*+ HashJoin(an ci lt ml t pi n it)
 HashJoin(an ci lt ml t pi n)
 HashJoin(ci lt ml t pi n)
 NestLoop(pi n)
 HashJoin(ci lt ml t)
 HashJoin(lt ml t)
 NestLoop(lt ml)
 SeqScan(an)
 SeqScan(ci)
 SeqScan(lt)
 IndexScan(ml)
 SeqScan(t)
 IndexScan(pi)
 IndexScan(n)
 SeqScan(it)
 Leading(((an ((ci ((lt ml) t)) (pi n))) it)) */
SELECT MIN(n.name) AS cast_member_name,
       MIN(pi.info) AS cast_member_info
FROM aka_name AS an,
     cast_info AS ci,
     info_type AS it,
     link_type AS lt,
     movie_link AS ml,
     name AS n,
     person_info AS pi,
     title AS t
WHERE an.name IS NOT NULL
  AND (an.name LIKE '%a%'
       OR an.name LIKE 'A%')
  AND it.info ='mini biography'
  AND lt.link IN ('references',
                  'referenced in',
                  'features',
                  'featured in')
  AND n.name_pcode_cf BETWEEN 'A' AND 'F'
  AND (n.gender='m'
       OR (n.gender = 'f'
           AND n.name LIKE 'A%'))
  AND pi.note IS NOT NULL
  AND t.production_year BETWEEN 1980 AND 2010
  AND n.id = an.person_id
  AND n.id = pi.person_id
  AND ci.person_id = n.id
  AND t.id = ci.movie_id
  AND ml.linked_movie_id = t.id
  AND lt.id = ml.link_type_id
  AND it.id = pi.info_type_id
  AND pi.person_id = an.person_id
  AND pi.person_id = ci.person_id
  AND an.person_id = ci.person_id
  AND ci.movie_id = ml.linked_movie_id;

