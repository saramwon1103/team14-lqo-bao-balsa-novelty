/*+ MergeJoin(chn n ci k mk it2 cct2 cct1 cc t kt mi_idx)
 HashJoin(n ci k mk it2 cct2 cct1 cc t kt mi_idx)
 MergeJoin(ci k mk it2 cct2 cct1 cc t kt mi_idx)
 HashJoin(k mk it2 cct2 cct1 cc t kt mi_idx)
 HashJoin(mk it2 cct2 cct1 cc t kt mi_idx)
 NestLoop(it2 cct2 cct1 cc t kt mi_idx)
 NestLoop(cct2 cct1 cc t kt mi_idx)
 HashJoin(cct2 cct1 cc t kt)
 HashJoin(cct1 cc t kt)
 HashJoin(cc t kt)
 NestLoop(t kt)
 IndexScan(chn)
 SeqScan(n)
 IndexScan(ci)
 SeqScan(k)
 SeqScan(mk)
 SeqScan(it2)
 SeqScan(cct2)
 IndexScan(cct1)
 SeqScan(cc)
 SeqScan(t)
 IndexScan(kt)
 IndexScan(mi_idx)
 Leading((chn (n (ci (k (mk (it2 ((cct2 (cct1 (cc (t kt)))) mi_idx)))))))) */
SELECT MIN(chn.name) AS character_name,
       MIN(mi_idx.info) AS rating,
       MIN(t.title) AS complete_hero_movie
FROM complete_cast AS cc,
     comp_cast_type AS cct1,
     comp_cast_type AS cct2,
     char_name AS chn,
     cast_info AS ci,
     info_type AS it2,
     keyword AS k,
     kind_type AS kt,
     movie_info_idx AS mi_idx,
     movie_keyword AS mk,
     name AS n,
     title AS t
WHERE cct1.kind = 'cast'
  AND cct2.kind LIKE '%complete%'
  AND chn.name IS NOT NULL
  AND (chn.name LIKE '%man%'
       OR chn.name LIKE '%Man%')
  AND it2.info = 'rating'
  AND k.keyword IN ('superhero',
                    'marvel-comics',
                    'based-on-comic',
                    'tv-special',
                    'fight',
                    'violence',
                    'magnet',
                    'web',
                    'claw',
                    'laser')
  AND kt.kind = 'movie'
  AND t.production_year > 2000
  AND kt.id = t.kind_id
  AND t.id = mk.movie_id
  AND t.id = ci.movie_id
  AND t.id = cc.movie_id
  AND t.id = mi_idx.movie_id
  AND mk.movie_id = ci.movie_id
  AND mk.movie_id = cc.movie_id
  AND mk.movie_id = mi_idx.movie_id
  AND ci.movie_id = cc.movie_id
  AND ci.movie_id = mi_idx.movie_id
  AND cc.movie_id = mi_idx.movie_id
  AND chn.id = ci.person_role_id
  AND n.id = ci.person_id
  AND k.id = mk.keyword_id
  AND cct1.id = cc.subject_id
  AND cct2.id = cc.status_id
  AND it2.id = mi_idx.info_type_id;

